package betternightvision.client;

import betternightvision.ModConfig;
import betternightvision.ModConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BetterNightVisionClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        // تعريف مفتاح F7 لتشغيل/إيقاف المود
        toggleKey = new KeyBinding(
            "key.betternightvision.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_F7,
            "category.betternightvision"
        );

        // تعريف مفتاح F8 لفتح الواجهة
        guiKey = new KeyBinding(
            "key.betternightvision.gui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_F8,
            "category.betternightvision"
        );

        // مراقبة الأزرار أثناء اللعب
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                ModConfig.enabled = !ModConfig.enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.literal("Better Night Vision: " + (ModConfig.enabled ? "§aON" : "§cOFF")), 
                        true
                    );
                }
            }

            while (guiKey.wasPressed()) {
                client.setScreen(new ModConfigScreen(client.currentScreen));
            }
        });
    }
}
