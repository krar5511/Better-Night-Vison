package betternightvision;

import java.util.ArrayList;
import java.util.List;

public class ModConfig {
    public static boolean enabled = true;
    public static float widthMultiplier = 1.0f;
    public static float heightMultiplier = 1.0f;
    public static List<String> blacklistedEntities = new ArrayList<>();
    public static List<String> excludedPlayers = new ArrayList<>();
}
