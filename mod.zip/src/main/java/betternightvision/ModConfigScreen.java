package betternightvision;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ModConfigScreen extends Screen {
    private final Screen parent;

    public ModConfigScreen(Screen parent) {
        super(Text.literal("Better Night Vision Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();
        
        // زر لتفعيل وإيقاف المود
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Toggle Mod: " + (ModConfig.enabled ? "ON" : "OFF")),
            button -> {
                ModConfig.enabled = !ModConfig.enabled;
                button.setMessage(Text.literal("Toggle Mod: " + (ModConfig.enabled ? "ON" : "OFF")));
            })
            .dimensions(this.width / 2 - 100, this.height / 4 + 24, 200, 20)
            .build());

        // زر العودة للعبة
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Done"),
            button -> this.client.setScreen(parent))
            .dimensions(this.width / 2 - 100, this.height / 4 + 120, 200, 20)
            .build());
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
