package betternightvision.mixin;

import betternightvision.ModConfig;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void onGetTargetingMargin(CallbackInfoReturnable<Float> cir) {
        if (!ModConfig.enabled) return;

        Entity entity = (Entity) (Object) this;

        // التحقق من اللاعبين المستثنين
        if (entity instanceof PlayerEntity player) {
            if (ModConfig.excludedPlayers.contains(player.getName().getString())) {
                return;
            }
        }

        // التحقق من قائمة الموبات المستثناة (Blacklist)
        String entityType = entity.getType().getRegistryPath();
        if (ModConfig.blacklistedEntities.contains(entityType)) {
            return;
        }

        // تطبيق التكبير على الهامش الخاص بالهتبوكس
        float current = cir.getReturnValue();
        cir.setReturnValue(current + (ModConfig.widthMultiplier - 1.0f));
    }
}
